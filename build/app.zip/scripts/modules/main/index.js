module.exports = {
    module: require("./src/module"),
    config: require("./src/config"),

    controllers: {
        main: require("./src/controllers/main")
    }
};
