// Define the module

module.exports = angular.module(
    "app",
    [
        "ui.bootstrap",
        "ui.router"
    ]
);
