## app/media Folder

Contains various media (Pictures, audio, video, etc...)
